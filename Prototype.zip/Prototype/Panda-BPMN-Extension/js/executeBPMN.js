var deployed = false;
var process_activeUserTask = false;
var process_activeServiceTask = false;
var activeTasksOld = new Array();
var activeUserTasksOld = new Array();
var userTaskId;
var processName;

var processId;


function setProcessId(id){
  this.processId = id;
}

function getProcessId(){
  return this.processId;
}


function startProcess(){

  //set black stroke for all objects
  $("g > g > rect").css("stroke","black");

  $.ajax({
    type : "POST",
    url : "../../../../engine-rest/process-definition/"+getProcessId()+"/start",
    datatype : "application/json",
    contentType: "application/json",
    success : function(data) {

        //process_active = true;
        process_activeServiceTask = true;
        process_activeUserTask = true;

        showToolbar(false);
        showPropertiesPanel(false);
        switchPlayPauseButton2(false);

        checkExecution();
        checkExecutionUserTasks();

    },
    error : function(error) {
     alert("error");
  }});
}

function deployProcess(){

    $("#play_pause_button").attr("src", "../Panda-BPMN-Extension/img/pause.png");

    var bpmn = $('#diagram').val();
    const blobDiagram = new Blob([bpmn], { type: 'text/xml' });

    var random = new Date().getTime();
    var fd = new FormData();
    fd.append('deployment-name', "Assembly_"+random);
    fd.append('deployment-source', "Panda BPMN Modeler");
    fd.append('deploy-changed-only', "true");
    fd.append('test.bpmn', blobDiagram, 'test.bpmn');

    $.ajax({
    type : "POST",
    url : "../../../../engine-rest/deployment/create",
    processData: false,
      contentType: false,
    data: fd,

    success : function(data) {

        setProcessId(Object.keys(data.deployedProcessDefinitions)[0]);
        startProcess();

    },
    error : function(error) {
    alert("error");
    }});

}

function checkExecution(){

  var count=0;
  var activeTasksNew = new Array();

  $.ajax({
    type : "GET",
    url : "../../../../engine-rest/external-task?processDefinitionId="+getProcessId(),
    datatype : "application/json",
    contentType: "application/json",
    success : function(data) {

              data.forEach(function(item){

                var nameOfTask = item.activityId;
                $("g[data-element-id='"+nameOfTask+"'] > g > rect").addClass("path");
                $("g[data-element-id='"+nameOfTask+"'] > g > rect").css("stroke","lightgreen");
                $("g[data-element-id='"+nameOfTask+"']").addClass("selected");

                activeTasksNew.push(nameOfTask);
                count++;

              });

              if(count==0){
                process_activeServiceTask = false;
              }
              else{
                process_activeServiceTask = true;
              }

             activeTasksOld.forEach(function(item){
                  if(!activeTasksNew.includes(item)){
                    $("g[data-element-id='"+item+"'] > g > rect").removeClass("path");
                    $("g[data-element-id='"+item+"'] > g > rect").css("stroke","black");
                  }
             });

             //set activeTasksNew to Old
             //clear activeTasksNew
             activeTasksOld = [];
             activeTasksNew.forEach(function(item){
                activeTasksOld.push(item);
             });

    },
    error : function(error) {
    alert("error");
  }});

  console.log("UserTask: "+process_activeUserTask);
  console.log("ServiceTask: "+process_activeServiceTask);

  if(process_activeServiceTask){
      showFrankaIframe(true);
  }
  else{
      showFrankaIframe(false);
  }

  if(process_activeServiceTask || process_activeUserTask){
    setTimeout(checkExecution,100);
    setTimeout(checkExecutionUserTasks,100);
    setTimeout(hideGroup,0);
  }
  else{
    $(".path").css("stroke","black");
    $(".path").removeClass("path");

    $(".group").css("visibility","");
    showToolbar(true);
    showPropertiesPanel(true);
    switchPlayPauseButton2(true);
  }
}

function hideGroup(){
  $(".djs-context-pad").remove();
  $(".group").css("visibility","hidden");
}

function checkExecutionUserTasks(){

  var count=0;
  var activeUserTasksNew = new Array();

  $.ajax({
    type : "GET",
    url : "../../../../engine-rest/task?processDefinitionId="+getProcessId(),
    datatype : "application/json",
    contentType: "application/json",
    success : function(data) {

            data.forEach(function(item){

              var nameOfTask = item.taskDefinitionKey;
              $("g[data-element-id='"+nameOfTask+"'] > g > rect").addClass("path");
              $("g[data-element-id='"+nameOfTask+"'] > g > rect").css("stroke","lightgreen");
              $("g[data-element-id='"+nameOfTask+"']").addClass("selected");

              //add click event
              var endEventNode = document.querySelectorAll("[data-element-id='"+nameOfTask+"']");
              endEventNode.forEach(element => element.addEventListener('click', completeUserTask, true));

              //remove additional panel on click
              $(".djs-context-pad").remove();

              activeUserTasksNew.push(nameOfTask);

              userTaskId = item.id;

              count++;

          });

          if(count==0){
             process_activeUserTask = false;
          }
          else{
            process_activeUserTask = true;
          }

          activeUserTasksOld.forEach(function(item){
            if(!activeUserTasksNew.includes(item)){
              $("g[data-element-id='"+item+"'] > g > rect").each(function(){
                $(this).removeClass("path");
              });

              $("g[data-element-id='"+item+"'] > g > rect").each(function(){
                $(this).css("stroke","black");
              });
            }
          });

          //set activeTasksNew to Old
          //clear activeTasksNew
          activeUserTasksOld = [];
          activeUserTasksNew.forEach(function(item){
            activeUserTasksOld.push(item);
          });
    },
    error : function(error) {
    alert("error");
  }});

}

function showToolbar(value){

  if(value == true){
    $(".djs-palette").css('visibility','');
    $("#play_pause_button").attr("src", "../Panda-BPMN-Extension/img/play.png");

    //js-drop-zone height: 100%
    $("#js-drop-zone").css('height','90%');

  }
  else{
    $(".djs-palette").css('visibility','hidden');
    $("#play_pause_button").attr("src", "../Panda-BPMN-Extension/img/pause.png");

    //js-drop-zone height: 60%
    $("#js-drop-zone").css('height','60%');
  }

}

function showPropertiesPanel(value){

  if(value == true){
    $("#js-properties-panel").css('visibility','');
  }
  else{
    $("#js-properties-panel").css('visibility','hidden');
  }

}

function switchPlayPauseButton2(value){

  if(value == true){
    $("#play_pause_button").attr("src", "../Panda-BPMN-Extension/img/play.png");
  }
  else{
    $("#play_pause_button").attr("src", "../Panda-BPMN-Extension/img/pause.png");
  }

}

function completeUserTask(){

  $.ajax({
    type : "POST",
    url : "../../../../engine-rest/task/"+userTaskId+"/complete",
    datatype : "application/json",
    contentType: "application/json",
    success : function(data) {
    },
    error : function(error) {
    }});

}

function convertString(string){

  string = string.toLowerCase();
  string = string.replace(/[^a-zA-Z0-9]/g,'_');

}

function showFrankaIframe(value){

  if(value == true){
    //show franka iframe
    $("#franka_iframe").css('visibility','');
  }
  else{
    //hide franka iframe
    $("#franka_iframe").css('visibility','hidden');
  }

}

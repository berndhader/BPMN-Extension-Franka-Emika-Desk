
exports.usernamePanda = "Desk_Username"
exports.passwordPanda = "Desk_Password"

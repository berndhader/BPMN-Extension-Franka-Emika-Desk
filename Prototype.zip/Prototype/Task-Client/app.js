
const pandaAuthenticationToken = "InsertToken";

const {
  Client,
  logger,
  Variables,
  File
} = require("camunda-external-task-client-js");

// configuration for the Client:
//  - 'baseUrl': url to the Workflow Engine
//  - 'logger': utility to automatically log important events
const config = { baseUrl: "http://localhost:8080/engine-rest", use: logger };

// create a Client instance with custom configuration
const client = new Client(config);

// susbscribe to the topic: 'pandaTaskExecution'
client.subscribe("pandaTaskExecution", async function({ task, taskService }) {

  console.log(pandaAuthenticationToken);

  var nameOfTask = task.variables.get("name");
  nameOfTask = convertString(nameOfTask);
  console.log(nameOfTask);

  var StateMachine = require('javascript-state-machine');

  var fsm = new StateMachine({
      init: 'open',
      transitions: [
        { name: 'start',     from: 'open',  to: 'running' },
        { name: 'end',   from: 'running', to: 'completed'  }
      ]
    });

  //send rest request to panda
  //Example POST method invocation
  var Client = require('node-rest-client').Client;
  var client = new Client();

  // set content-type header and data as json in args parameter
  var args = {
      data: { id: nameOfTask },
      headers: { "Content-Type": "application/x-www-form-urlencoded",
                 "Authorization": pandaAuthenticationToken
               }
  };

  client.post("https://robot.franka.de/desk/api/execution", args, async function (data, response) {

      fsm.start();

      while(fsm.is("running")){

        console.log("running");

        var client_checkState = new Client();
        var args = {
            headers: { "Authorization": pandaAuthenticationToken }
        };

        await client_checkState.get("https://robot.franka.de/desk/api/execution", args, async function (data, response) {

            data = data.toString('utf8');

            var json_obj = JSON.parse(data);

            if(json_obj.state.active === false){
              fsm.end();
              await taskService.complete(task);
            }
        });

        await new Promise(resolve => setTimeout(resolve, 100));

      }

  });

});

function convertString(string){

    string = string.toLowerCase();
    string = string.replace(/[^a-zA-Z0-9]/g,'_');
    return string;

}

const {
  Client,
  logger,
  Variables,
  File
} = require("camunda-external-task-client-js");

//import settings
var settings = require("./settings.js");

console.log(settings.usernamePanda);
console.log(settings.passwordPanda);

// configuration for the Client:
//  - 'baseUrl': url to the Workflow Engine
//  - 'logger': utility to automatically log important events
const config = { baseUrl: "http://localhost:8080/engine-rest", use: logger };

// create a Client instance with custom configuration
const client = new Client(config);

// susbscribe to the topic: 'pandaTaskExecution'
client.subscribe("pandaTaskExecution", async function({ task, taskService }) {

  var crypto = require('crypto');
  var bs = settings.passwordPanda + '#' + settings.usernamePanda + "@franka";

//hash with sha256
var bsHash = crypto.createHash('sha256').update(bs).digest('hex');


//split hash into groups of 2 and convert to int

var chunks = [];
for(var i = 0, charsLength = bsHash.length; i < charsLength; i+=2){
  var val = bsHash.substring(i, i+2);
  chunks.push(parseInt(val,16));
}


chunksString = chunks.toString();

var encryptedBytes = Buffer.from(chunksString);
var passwordEncrypted = encryptedBytes.toString('base64');



  var Client = require('node-rest-client').Client;


  var client_getToken = new Client();

  client_getToken.parsers.remove("JSON");

  client_getToken.parsers.add({
           "name":"JSON",
           "isDefault": true,
             "match":function(response){},
             "parse":function(byteBuffer,nrcEventEmitter,parsedCallback){

          data = byteBuffer.toString();

        parsedCallback(data);

        },
             // of course any other args or methods can be added to parser
             "otherAttr":"my value",
             "otherMethod":function(a,b,c){}
          });


   var args = {
      data: { login: settings.usernamePanda, password: passwordEncrypted },
      headers: { "Content-Type": "application/json"},

  };


    client_getToken.post("https://robot.franka.de/admin/api/login", args, function (data, response) {

      var pandaAuthenticationToken = data;

      var nameOfTask = task.variables.get("name");
      nameOfTask = convertString(nameOfTask);
      console.log(nameOfTask);

      var StateMachine = require('javascript-state-machine');

      var fsm = new StateMachine({
          init: 'open',
          transitions: [
            { name: 'start',     from: 'open',  to: 'running' },
            { name: 'end',   from: 'running', to: 'completed'  }
          ]
        });

      //send rest request to panda
      //Example POST method invocation
      var Client = require('node-rest-client').Client;
      var client = new Client();

    //  var pandaAuthenticationToken =  await getToken();
        console.log("panda" + pandaAuthenticationToken);

      // set content-type header and data as json in args parameter
      var args = {
          data: { id: nameOfTask },
          headers: { "Content-Type": "application/x-www-form-urlencoded",
                     "Authorization": pandaAuthenticationToken
                   }
      };

      client.post("https://robot.franka.de/desk/api/execution", args, async function (data, response) {

          fsm.start();

          while(fsm.is("running")){

            console.log("running");
            console.log("Token" + pandaAuthenticationToken);
            var client_checkState = new Client();
            var args = {
                headers: { "Authorization": pandaAuthenticationToken }
            };

            await client_checkState.get("https://robot.franka.de/desk/api/execution", args, async function (data, response) {

                data = data.toString('utf8');

                var json_obj = JSON.parse(data);

                if(json_obj.state.active === false){
                  fsm.end();
                  await taskService.complete(task);
                }
            });

            await new Promise(resolve => setTimeout(resolve, 100));

          }

      });

        });



//bishier
});

function convertString(string){

    string = string.toLowerCase();
    string = string.replace(/[^a-zA-Z0-9]/g,'_');
    return string;

}
